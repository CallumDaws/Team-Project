package com.example.victorwang.campuschase;

public class ScoreManagerTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ScoreManager scoreManager = new ScoreManager();
        scoreManager.updateScores();
    }

}
