#!/bin/bash
# Upload files to the droplet

scp app.js treasurehunt@178.62.97.13:~/app/


scp /home/ben/Team-Programming-Project/Backend/app.js treasurehunt@178.62.97.13:~/app
scp /home/ben/Team-Programming-Project/Backend/colours.json treasurehunt@178.62.97.13:~/app
scp /home/ben/Team-Programming-Project/Backend/questions.json root@178.62.97.13:/var/www/treasurehunt/static/json
scp /home/ben/Team-Programming-Project/Backend/stats.js treasurehunt@178.62.97.13:~/app



scp proxies.txt root@178.62.97.13:~/proxychecker
scp proxychecker.js root@178.62.97.13:~/proxychecker


scp scraper.js root@178.62.97.13:~/pastebin
scp package.json root@178.62.97.13:~/pastebin


scp /home/ben/Team-Programming-Project/Backend/questions.json root@178.62.97.13:/var/www/treasurehunt/static/json
scp /home/ben/Team-Programming-Project/Backend/stats.html root@178.62.97.13:/var/www/treasurehunt/