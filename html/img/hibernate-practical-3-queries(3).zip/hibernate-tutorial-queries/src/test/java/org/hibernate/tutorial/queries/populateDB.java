/**
 * 
 */
package org.hibernate.tutorial.queries;

import java.sql.Time;
import java.util.HashSet;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


/**
 * @author paolo Missier
 *
 */
public class populateDB extends TestCase {

	private SessionFactory sessionFactory;
	private Session session;

	@Override
	protected void setUp() throws Exception {
		// A SessionFactory is set up once for an application
		sessionFactory = new Configuration()
		.configure() // configures settings from hibernate.cfg.xml
		.buildSessionFactory();
		session = sessionFactory.openSession();
	}

	@Override
	protected void tearDown() throws Exception {
		if ( sessionFactory != null ) {
			sessionFactory.close();
		}
	}


	public void testPopulateDB() {

		session.beginTransaction();

		try {

			Query q = session.createSQLQuery("delete from ARTIST_EMAIL_ADDR");			
			q.executeUpdate();
			
			q = session.createSQLQuery("delete from ARTISTS_TRACK");			
			q.executeUpdate();

			q = session.createSQLQuery("delete from ARTIST");			
			q.executeUpdate();

			q = session.createSQLQuery("delete from TRACK");
			q.executeUpdate();

			q = session.createSQLQuery("delete from ALBUM");
			q.executeUpdate();


			session.getTransaction().commit();

		} catch (Exception e) {
			System.out.println("Exception: "+e.getLocalizedMessage());
			System.out.println("Transaction rolled back");
			session.getTransaction().rollback();
		}

		
		// adding Ablums
		session.beginTransaction();

		try {

			Album album = new Album();
			album.setId(100);
			album.setName("Orblivion");
			album.setTracks(new HashSet<Track>());

			session.save(album);

			album = new Album();
			album.setId(200);
			album.setName("Back to mine");
			album.setTracks(new HashSet<Track>());

			session.save(album);

			session.getTransaction().commit();

		} catch (Exception e) {
			System.out.println("Exception: "+e.getLocalizedMessage());
			System.out.println("Transaction rolled back");
			session.getTransaction().rollback();
		}

		// adding Artists
		session.beginTransaction();

		try {
			Artist artist = new Artist();
			artist.setId(1);						
			artist.setName("Laurie Anderson");						
			artist.getEmailAddresses().add("laurie.anderson@GBCG.ny");
			artist.getEmailAddresses().add("landerson@gmail.com");

			session.save(artist);

			artist = new Artist();
			artist.setId(2);						
			artist.setName("Peter Gabriel");
			session.save(artist);

			artist = new Artist();
			artist.setId(3);						
			artist.setName("Paolo Fresu");
			artist.getEmailAddresses().add("paolo.fresu@jazz.it");
			artist.getEmailAddresses().add("pfresu@gmail.com");
			session.save(artist);

			session.getTransaction().commit();

		} catch (Exception e) {
			System.out.println("Exception: "+e.getLocalizedMessage());
			System.out.println("Transaction rolled back");
			session.getTransaction().rollback();
		}

		// adding Tracks
		System.out.println("*** adding Tracks ***");
		session.beginTransaction();

		Track track;
		try {
			track = new Track();
			track.setId(10);
			track.setTitle("my song");
			track.setPlayTime(Time.valueOf("00:04:45"));
			track.setVolume( (short) 32);
			track.setFilePath("/Media/blah");
			session.save( track );

			track = new Track();
			track.setId(20);
			track.setTitle("Russian Trance");
			track.setFilePath("vol2/album611/track02.mp3");
			track.setVolume( (short) 23);
			track.setPlayTime(Time.valueOf("00:03:30"))	;        
			session.save(track);

			track = new Track();
			track.setId(30);
			track.setTitle("Gravity's Angel");
			track.setFilePath("vol2/album175/track03.mp3");
			track.setVolume( (short) 11);
			track.setPlayTime(Time.valueOf("00:06:06"));
			session.save(track);

			session.getTransaction().commit();

		} catch (Exception e) {
			System.out.println("Exception: "+e.getLocalizedMessage());
			System.out.println("Transaction rolled back");
			session.getTransaction().rollback();
		}

		System.out.println("*** assoc tracks to Albums ***");
		session.beginTransaction();

		//		try {
		// find album with id = 100
		Album album = (Album) session.load(Album.class, 100);

		if (album != null) {

			// add all tracks to this album
			List result = session.createQuery( "from Track" ).list();
			for ( Track tr : (List<Track>) result ) {
				System.out.println( "adding Track (" + tr.getTitle() + ") : " + "to album: " + album.getName() );
				album.getTracks().add(tr);
				tr.setAlbumRef(album);
				session.save(tr);
			}
			session.save(album);

		}
		session.getTransaction().commit();

		//		} catch (Exception e) {
		//			System.out.println("Exception: "+e.getLocalizedMessage());
		//			System.out.println("Transaction rolled back");
		//			session.getTransaction().rollback();
		//		}
		//


		System.out.println("*** assoc tracks to artists ***");
		Artist aArtist;
		Track aTrack;
		try {
			session.beginTransaction();		

			aArtist = (Artist) session.load(Artist.class, 3);

			aTrack = (Track)  session.load(Track.class, 20);		
			aArtist.getTracks().add(aTrack);
			aTrack.getArtists().add(aArtist);
			session.save(aTrack);

			aTrack = (Track)  session.load(Track.class, 30);		
			aArtist.getTracks().add(aTrack);
			aTrack.getArtists().add(aArtist);
			session.save(aTrack);

			session.save(aArtist);			

			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("Exception: "+e.getLocalizedMessage());
			System.out.println("Transaction rolled back");
			session.getTransaction().rollback();
		}

		try {
			session.beginTransaction();		
			aArtist = (Artist) session.load(Artist.class, 1);
			aTrack  = (Track)  session.load(Track.class, 30);		

			aArtist.getTracks().add(aTrack);
			aTrack.getArtists().add(aArtist);
			session.save(aTrack);

			aArtist = (Artist) session.load(Artist.class, 1);
			aTrack  = (Track)  session.load(Track.class, 10);		

			aArtist.getTracks().add(aTrack);
			aTrack.getArtists().add(aArtist);
			session.save(aTrack);

			session.save(aArtist);

			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("Exception: "+e.getLocalizedMessage());
			System.out.println("Transaction rolled back");
			session.getTransaction().rollback();
		}
		session.close();
	}

}
