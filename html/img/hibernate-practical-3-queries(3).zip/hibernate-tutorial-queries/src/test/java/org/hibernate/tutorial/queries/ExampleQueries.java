/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.tutorial.queries;

import java.sql.Time;
import java.util.Date;
import java.util.List;
import java.util.Set;

import junit.framework.TestCase;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.Criteria;

/**
 * Retrieves Track objects from the DB
 *
 * @author Paolo Missier
 */
public class ExampleQueries extends TestCase {
	private SessionFactory sessionFactory;

	@Override
	protected void setUp() throws Exception {
		// A SessionFactory is set up once for an application
		sessionFactory = new Configuration()
		.configure() // configures settings from hibernate.cfg.xml
		.buildSessionFactory();
	}

	@Override
	protected void tearDown() throws Exception {
		if ( sessionFactory != null ) {
			sessionFactory.close();
		}
	}

	public void testRetrieveTracksUsingQuery() {

		Session session = sessionFactory.openSession();
		session.beginTransaction();

		// in this version we start with a more articulate query
		// retrieve Tracks with a parameter

		/***********
 HIbernate queries with parameters by name
		 **************/

		// create a Hibernate Query object
		Query q = session.createQuery( "from Track where filePath like :search" );

		// bind the parameters 
		q.setString("search", "vol2%");

		// execute the query
		List result = q.list();

		System.out.println("+++ testing basic HQL query with parameters +++");		
		// iterate through the results
		reportTrackResults(result);

		/***********
HIbernate named queries
		 **************/

		// this query is defined in the Track class
		String titleSearch = "%Trance%";  // this would be obtained from the user 
		q = session.getNamedQuery("findTracksByTitleSubstring").setString("titleSearch", titleSearch);

		System.out.println("+++ testing named query +++");
		reportTrackResults(q.list());


		/***********
HIbernate criteria queries - Hibernate only  (see ch. 15.1) 
		 **************/

		Criteria crit = session.createCriteria(Artist.class);

		// add ordering clause
		crit.addOrder(org.hibernate.criterion.Order.asc("name"));

		// add a restriction. This works like a WHERE clause
		Criterion firstInitialEq = org.hibernate.criterion.Restrictions.ilike("name", "P", org.hibernate.criterion.MatchMode.START);

		crit.add(firstInitialEq);

		List<Artist> artistsResult = crit.list(); 

		System.out.println("+++\n+++ artists matching restriction criteria ");
		reportArtistsResults(artistsResult);

		/***********
		 SQL   (15.2)
		 **************/

		artistsResult = session.createSQLQuery("select * from Artist").addEntity(Artist.class).list();

		System.out.println("+++\n+++ artists retrieved using Hibernate SQL query:");
		reportArtistsResults(artistsResult);
		
		List nativeQueryResult = session.createSQLQuery("select a.name as artistName, t.title as trackTitle, t.volume "+
										"from Artist a " +
		                                "left outer join Artists_Track at on a.artist_Id= at.artist_id " +
		                                "join Track t on at.track_id = t.track_id").
		                                addScalar("artistName", org.hibernate.type.StringType.INSTANCE).
		                                addScalar("trackTitle", org.hibernate.type.StringType.INSTANCE).
		                                addScalar("t.volume", org.hibernate.type.IntegerType.INSTANCE).
		                                list();

		System.out.println("+++\n+++ more complex native SQL join query:");
		for ( Object[] o: (List<Object[]>) nativeQueryResult ) {
			System.out.println("Artist: "+ (String) o[0]+ " Track: "+ (String) o[1]+" track volume: "+(Integer) o[2]);
		}

		session.getTransaction().commit();
		session.close();

	}


	/***********
Queries with joins -- compare with the Artist -> Track navigational queries above
	 **************/


	private void reportArtistsResults(List<Artist> result) {

		for ( Artist art : (List<Artist>) result ) {
			System.out.println( "Artist: " + art.getName());

			System.out.println("tracks");
			// retrieve all associated tracks
			for (Track tr: art.getTracks()  ) {
				System.out.println(tr.getTitle());			
			}

			System.out.println("emails");
			// retrieve all associated emails
			for (String email: art.getEmailAddresses()  ) {
				System.out.println(email);			
			}

		}

	}



	private void reportTrackResults(List result)   {
		for ( Track tr : (List<Track>) result ) {
			System.out.println( "****\nTrack " + tr.getId() + " ( "+ tr.getTitle() + ") with file path "+tr.getFilePath()+" : " + tr.getPlayTime() + "  has artists: ");

			// navigate to associated Artist objects
			for (Artist art: tr.getArtists()) {
				System.out.println(art.getName());
				// from artists, navigate to their emailAddresses
				System.out.println("this artist's emails:");
				for (String email: art.getEmailAddresses()) {
					System.out.println(email);
				}
			}
		}

	}


}
