package org.hibernate.tutorial.queries;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="ARTIST")
public class Artist {

	@Id  @Column(name="ARTIST_ID")
	private int id;
	
	@Column(nullable=false,unique=true)
	private String name;
	
    @ElementCollection
    @CollectionTable(name="ARTIST_EMAIL_ADDR", joinColumns=@JoinColumn(name="ARTIST_ID"))
    @Column(name="EMAIL_ADDR")
    private Set<String> emailAddresses = new HashSet<String>();

    @ManyToMany(
            targetEntity=Track.class,
            cascade={CascadeType.PERSIST, CascadeType.MERGE}
        )
        @JoinTable(
            name="ARTISTS_TRACK",
            joinColumns=@JoinColumn(name="ARTIST_ID"),
            inverseJoinColumns=@JoinColumn(name="TRACK_ID")
        )
	private Set<Track> tracks = new HashSet<Track>();

    
	 public Artist() {
	}
	 	 

    public Set<String> getEmailAddresses() {
        return emailAddresses;
    }

    public void setEmailAddresses(Set<String> emailAddresses) {
        this.emailAddresses = emailAddresses;
    }

    /**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the tracks
	 */
	public Set<Track> getTracks() {
		return tracks;
	}
	/**
	 * @param tracks the tracks to set
	 */
	public void setTracks(Set<Track> tracks) {
		this.tracks = tracks;
	}
	 
	 
}
