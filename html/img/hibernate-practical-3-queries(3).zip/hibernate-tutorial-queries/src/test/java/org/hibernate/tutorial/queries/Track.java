/*
 * Hibernate, Relational Persistence for Idiomatic Java
 *
 * Copyright (c) 2010, Red Hat Inc. or third-party contributors as
 * indicated by the @author tags or express copyright attribution
 * statements applied by the authors.  All third-party contributions are
 * distributed under license by Red Hat Inc.
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.hibernate.tutorial.queries;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.sql.Time;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.CascadeType;

@org.hibernate.annotations.NamedQueries({
	@org.hibernate.annotations.NamedQuery(
			name="findTracksByTitleSubstring",
			query="from Track where title like :titleSearch")					
})

@Entity
@Table( name = "TRACK" )
public class Track {
	
	@Id  @Column(name="TRACK_ID")
	private int id;
	
	private String title;
	private String filePath;
	private Time playTime;
	private Date added;
	private short volume;
	
	@ManyToOne
    @JoinColumn(name="ALBUM_ID")
	private Album albumRef;
	
	@ManyToMany(
	        cascade = {CascadeType.PERSIST, CascadeType.MERGE},
	        mappedBy = "tracks",
	        targetEntity = Artist.class)
	private Set<Artist> artists = new HashSet<Artist>();
	
	public Track() {
	}

	
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}
	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	/**
	 * @return the playTime
	 */
	public Date getPlayTime() {
		return playTime;
	}
	/**
	 * @param playTime the playTime to set
	 */
	public void setPlayTime(Time playTime) {
		this.playTime = playTime;
	}
	/**
	 * @return the added
	 */
	public Date getAdded() {
		return added;
	}
	/**
	 * @param added the added to set
	 */
	public void setAdded(Date added) {
		this.added = added;
	}
	/**
	 * @return the volume
	 */
	public short getVolume() {
		return volume;
	}
	/**
	 * @param volume the volume to set
	 */
	public void setVolume(short volume) {
		this.volume = volume;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the artists
	 */
	public Set<Artist> getArtists() {
		return artists;
	}

	/**
	 * @param artists the artists to set
	 */
	public void setArtists(Set<Artist> artists) {
		this.artists = artists;
	}

	/**
	 * @return the album_id
	 */
	public Album getAlbumRef() {
		return albumRef;
	}

	/**
	 * @param album_id the album_id to set
	 */
	public void setAlbumRef(Album albumRef) {
		this.albumRef = albumRef;
	}

}